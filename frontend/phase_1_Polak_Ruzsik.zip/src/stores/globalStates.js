import { ref } from 'vue'

export const ISLOGGEDIN = ref(false)
export const FIRSTNAME = ref('')
export const LASTNAME = ref('')
export const NICKNAME = ref('')
export const EMAIL = ref('')
export const PASSWORD = ref('')
export const CONFIRMPASSWORD = ref('')
